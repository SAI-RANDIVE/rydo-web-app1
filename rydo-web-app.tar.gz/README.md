# RYDO Web App - MongoDB Version

## Deployment Instructions

This application is configured for deployment on Render.com. Follow these steps:

1. Sign up for a Render.com account at https://render.com
2. Create a new Web Service
3. Upload this directory to Render.com
4. Set the following configuration:
   - Build Command: `npm install && node netlify-deploy.js`
   - Start Command: `node backend/server.js`
5. Add the required environment variables:
   - MONGODB_URI: Your MongoDB connection string
   - SESSION_SECRET: A secure random string
   - GOOGLE_MAPS_API_KEY: Your Google Maps API key
   - EMAIL_SERVICE: gmail
   - EMAIL_USER: Your email for sending OTPs
   - EMAIL_PASSWORD: Your app password for the email
   - RAZORPAY_KEY_ID: Your Razorpay key ID
   - RAZORPAY_KEY_SECRET: Your Razorpay key secret
   - RAZORPAY_COMMISSION_PERCENTAGE: 7.5
6. Deploy the application

## Features

- User authentication with OTP verification
- Booking system for drivers, caretakers, and shuttle services
- Real-time tracking of service providers
- Payment processing with Razorpay integration
- Rating and review system
- Admin dashboard for monitoring

## Technology Stack

- Backend: Node.js with Express.js
- Database: MongoDB (migrated from MySQL)
- Frontend: HTML, CSS, JavaScript
- Real-time Features: WebSockets
- Authentication: Session-based with OTP verification
